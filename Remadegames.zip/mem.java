
import java.lang.Math;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
//This is my finbal

public class mem {
    // initialize variables for storage and buttons which holds the sequence for which order of color to click each button in 
    ArrayList<String> storage = new ArrayList<>();
    int turn = 0;
    boolean lose = false;
    JButton red = new JButton("red");
    JButton green = new JButton("green");
    JButton blue = new JButton("blue");
    JButton yellow = new JButton("yellow");
    JButton playAgain = new JButton("Play Again"); // New button for playing again
    int on = 0;
    int scoreNum = 0;
    JLabel scoreLabel = new JLabel("Score: 0");
    // save original Icons for each button to reset after a timer to flash the color
    Icon originalRedIcon = red.getIcon();
    Icon originalGreenIcon = green.getIcon();
    Icon originalBlueIcon = blue.getIcon();
    Icon originalYellowIcon = yellow.getIcon();

    public mem() {
        // making JFrame structures 
        JFrame frame = new JFrame("Memory Game");
        
        JPanel buts = new JPanel();
        JPanel score = new JPanel();
        JPanel playPanel = new JPanel(); // Panel to hold the "Play Again" button
        
        // making A gridBagLayout so I can change the size of each JPanel
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 0.75; 
        gbc.fill = GridBagConstraints.BOTH;
        frame.add(buts, gbc);
        
        gbc.gridy = 1;
        gbc.weighty = 0.05;
        frame.add(playPanel, gbc); // Add the play panel
        
        gbc.gridy = 2;
        gbc.weighty = 0.2;
        frame.add(score, gbc);
        
        buts.setLayout(new GridLayout(1, 4));
        score.setLayout(new GridLayout(1, 1));
        playPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Set layout for play panel
        
        // making score JLabel
        score.add(scoreLabel);
        
        // making array list that holds 4 options of colors that get randomly generated later and get added to storage 
        ArrayList<String> ops = new ArrayList<>();
        ops.add("green");
        ops.add("yellow");
        ops.add("red");
        ops.add("blue");
        
        frame.setSize(1024, 576);
        buts.add(red);
        buts.add(green);
        buts.add(blue);
        buts.add(yellow);
        green.addActionListener(new ButtonClickListener("green"));
        blue.addActionListener(new ButtonClickListener("blue"));
        yellow.addActionListener(new ButtonClickListener("yellow"));
        red.addActionListener(new ButtonClickListener("red"));
        
        playPanel.add(playAgain); // Add the play again button to the play panel
        playAgain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                restartGame(); // When the play again button is clicked, restart the game
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        startNewTurn();
    }
    
    // starts the part where the computer shows the pattern, gets called again after player completes the pattern
    private void startNewTurn() {
        if (lose) {
            return;
        }
        
        int rand = (int) (Math.random() * 4);
        ArrayList<String> ops = new ArrayList<>();
        ops.add("green");
        ops.add("yellow");
        ops.add("red");
        ops.add("blue");
        
        storage.add(ops.get(rand));
        on = 0;
        displayOps(storage);
        turn = 1;
    }
    
    // method that displays the current pattern stored in storage
    public void displayOps(ArrayList<String> sto) {
        Icon redIcon = new ImageIcon("Red.png");
        Icon greenIcon = new ImageIcon("Green.png");
        Icon yellowIcon = new ImageIcon("Yellow.png");
        Icon blueIcon = new ImageIcon("Blue.png");
        // making a timer that set for 0.75 seconds for the flashing of colors gets faster as games goes on max score is 75
        Timer timer = new Timer(750-(scoreNum*10), null);
        ActionListener actionListener = new ActionListener() {
            int index = 0;

            // flashes the colors for each button depending on what color storage holds on index 
            public void actionPerformed(ActionEvent e) {
                if (index > 0) {
                    resetIcons();
                }
                if (index < sto.size()) {
                    String color = sto.get(index);
                    switch (color) {
                        case "red":
                            red.setIcon(redIcon);
                            break;
                        case "green":
                            green.setIcon(greenIcon);
                            break;
                        case "blue":
                            blue.setIcon(blueIcon);
                            break;
                        case "yellow":
                            yellow.setIcon(yellowIcon);
                            break;
                    }
                    index++;
                } else {
                    timer.stop();
                    turn = 1;
                }
            }
        };
        timer.addActionListener(actionListener);
        timer.start();
    }

    private void resetIcons() {
        red.setIcon(originalRedIcon);
        green.setIcon(originalGreenIcon);
        blue.setIcon(originalBlueIcon);
        yellow.setIcon(originalYellowIcon);
    }
    
    // handles if the player clicks the correct order of colors and shows "You lose" if not
    private class ButtonClickListener implements ActionListener {
        String color;

        public ButtonClickListener(String color) {
            this.color = color;
        }

        // increases on and checks if the button the player clicked is equal to the storage of index on
        public void actionPerformed(ActionEvent e) {
            if (turn == 1) {
                if (color.equals(storage.get(on))) {
                    on++;
                    if (on == storage.size()) {
                        turn = 0;
                        scoreNum++;
                        scoreLabel.setText("Score: " + scoreNum);
                        startNewTurn();
                    }
                } else {
                    lose = true;
                    JOptionPane.showMessageDialog(null, "You lost!");
                }
            }
        }
    }
    
    // restarts the game when "Play Again" button is clicked
    private void restartGame() {
        storage.clear(); // Clear the stored sequence
        scoreNum = 0; // Reset score
        scoreLabel.setText("Score: " + scoreNum); // Update score label
        lose = false; // Reset lose status
        startNewTurn(); // Start a new turn
    }
    
    // main function 
    public static void main(String[] args) {
        new mem();
    }
}
