import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Sudoku extends JFrame {
    private JTextField[][] cells;

    public Sudoku() {
        setTitle("Sudoku");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the board
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 9));
        cells = new JTextField[9][9];
        //making all of the text fields and has rules for what can be typed in each one
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                //adds all textfields to the cell 2d array in order
                cells[row][col] = new JTextField();
                cells[row][col].setHorizontalAlignment(JTextField.CENTER);
                cells[row][col].setFont(new Font("Arial", Font.BOLD, 20));
                
                panel.add(cells[row][col]);
            }
        }

        add(panel, BorderLayout.CENTER);

        // Add a button to check for win
        JButton checkWinButton = new JButton("Check Win");
        checkWinButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (checkForWin()) {
                    JOptionPane.showMessageDialog(Sudoku.this, "You Win!");
                } else {
                    JOptionPane.showMessageDialog(Sudoku.this, "Not a Winning Board.");
                }
            }
        });

        add(checkWinButton, BorderLayout.SOUTH);

        initializeBoard();
        setVisible(true);
    }
    // making pre generated board
    private void initializeBoard() {
        int[][] puzzle = {
            {5, 3, 0, 0, 7, 0, 0, 0, 0},
            {6, 0, 0, 1, 9, 5, 0, 0, 0},
            {0, 9, 8, 0, 0, 0, 0, 6, 0},
            {8, 0, 0, 0, 6, 0, 0, 0, 3},
            {4, 0, 0, 8, 0, 3, 0, 0, 1},
            {7, 0, 0, 0, 2, 0, 0, 0, 6},
            {0, 6, 0, 0, 0, 0, 2, 8, 0},
            {0, 0, 0, 4, 1, 9, 0, 0, 5},
            {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };
        //sets the cells that have the key puzzle peices to not be editable
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (puzzle[row][col] != 0) {
                    cells[row][col].setText(String.valueOf(puzzle[row][col]));
                    cells[row][col].setEditable(false);
                    cells[row][col].setBackground(Color.LIGHT_GRAY);
                }
            }
        }
    }
    //runs after clicking the play again button
    private boolean checkForWin() {
        // Check rows and columns
        for (int i = 0; i < 9; i++) {
            if (!isValidSet(getRow(i)) || !isValidSet(getColumn(i))) {
                return false;
            }
        }

        // Check 3x3 sub-grids
        for (int row = 0; row < 9; row += 3) {
            for (int col = 0; col < 9; col += 3) {
                if (!isValidSet(getSubGrid(row, col))) {
                    return false;
                }
            }
        }

        return true;
    }
    //returns a array full of the entire row 
    private int[] getRow(int row) {
        int[] result = new int[9];
        for (int col = 0; col < 9; col++) {
            result[col] = getCellValue(cells[row][col]);
        }
        return result;
    }
    //same as the row but for a collumn 
    private int[] getColumn(int col) {
        int[] result = new int[9];
        for (int row = 0; row < 9; row++) {
            result[row] = getCellValue(cells[row][col]);
        }
        return result;
    }
    // gets each 3x3 grid 
    private int[] getSubGrid(int startRow, int startCol) {
        int[] result = new int[9];
        int index = 0;
        for (int row = startRow; row < startRow + 3; row++) {
            for (int col = startCol; col < startCol + 3; col++) {
                result[index++] = getCellValue(cells[row][col]);
            }
        }
        return result;
    }
    //gets each single cell value since we have a 2d array of cells we can call this if we need a value
    private int getCellValue(JTextField cell) {
        String text = cell.getText();
        if (text.isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    //checks each 3x3 if there is any dulicates checks wheather each is outside the rang of 1-9 and if it has been seen if not add that number to be seen
    private boolean isValidSet(int[] set) {
        boolean[] seen = new boolean[10];
        
        for (int num : set) {
            if (num < 1 || num > 9 || seen[num]) {
                return false;
            }
            seen[num] = true;
        }
        return true;
    }

    public static void main(String[] args) {
        new Sudoku();
    }
}
