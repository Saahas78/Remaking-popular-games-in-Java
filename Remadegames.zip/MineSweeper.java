import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;

public class MineSweeper {
    String[][] arrs = new String[8][8];
    int flags = 10;
    int revealedCells = 0;
    int totalMines = 10;
    ArrayList<JButton> buts = new ArrayList<>();

    public MineSweeper() {
        JFrame frame = new JFrame("Minesweeper");
        JPanel cards = new JPanel();
        frame.setLayout(new GridLayout(1, 1));
        cards.setLayout(new GridLayout(8, 8));
        arrs = makeArray();
        frame.setSize(1024, 1024);
        frame.add(cards);

        //make buttons 
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                JButton but = new JButton("?");
                but.addMouseListener(new CustomMouseAdapter(i, j));
                but.setOpaque(true);
                but.setContentAreaFilled(true);
                buts.add(but);
                but.setBorderPainted(false);
                cards.add(but);
            }
        }

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private class CustomMouseAdapter extends MouseAdapter {
        private int x;
        private int y;

        public CustomMouseAdapter(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public static int AdjMines(String[][] minefield, int x, int y) {
            int mineCount = 0;
            int startX = x > 0 ? x - 1 : x;
            int startY = y > 0 ? y - 1 : y;
            int endX = x < 7 ? x + 1 : x;
            int endY = y < 7 ? y + 1 : y;

            for (int i = startX; i <= endX; i++) {
                for (int j = startY; j <= endY; j++) {
                    if (!(i == x && j == y) && minefield[i][j].equals("mine")) {
                        mineCount++;
                    }
                }
            }
            return mineCount;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            JButton button = (JButton) e.getSource();
            if (SwingUtilities.isLeftMouseButton(e)) {
                System.out.println("Left click at (" + x + ", " + y + ")");
                if (arrs[x][y].equals("mine")) {
                    button.setText("mine");
                    JOptionPane.showMessageDialog(button, "You Lost!");
                    revealAllMines();
                } else if (arrs[x][y].equals("no mine") && button.getText().equals("?")) {
                    int adjacentMines = AdjMines(arrs, x, y);
                    button.setText(String.valueOf(adjacentMines));
                    revealedCells++;
                    if (checkWin()) {
                        JOptionPane.showMessageDialog(button, "You Won!");
                    }
                }
            } else if (SwingUtilities.isRightMouseButton(e)) {
                System.out.println("Right click at (" + x + ", " + y + ")");
                if (button.getText().equals("?")) {
                    button.setText("flag");
                    flags--;
                } else if (button.getText().equals("flag")) {
                    button.setText("?");
                    flags++;
                }
                if (checkWin()) {
                    JOptionPane.showMessageDialog(button, "You Won!");
                }
            }
        }
    }

    public String[][] makeArray() {
        ArrayList<String> words = new ArrayList<>();
        for (int i = 0; i < 54; i++) {
            words.add("no mine");
        }
        for (int j = 0; j < 10; j++) {
            words.add("mine");
        }

        Collections.shuffle(words);

        String[][] arr = new String[8][8];
        int co = 0;
        for (int k = 0; k < 8; k++) {
            for (int h = 0; h < 8; h++) {
                arr[k][h] = words.get(co);
                co++;
            }
        }

        return arr;
    }

    private void revealAllMines() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (arrs[i][j].equals("mine")) {
                    JButton button = buts.get(i * 8 + j);
                    button.setText("mine");
                }
            }
        }
    }

    private boolean checkWin() {
        if (flags == totalMines && revealedCells == (64 - totalMines)) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        new MineSweeper();
    }
}
