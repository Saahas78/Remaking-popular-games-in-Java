import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;

public class Memory {
    String[][] arrs = new String[6][6];
    int flipped = 0;
    JButton prevBut;
    String prev;
    int gl = 60;
    ArrayList<JButton> buts = new ArrayList<JButton>();

    public Memory() {
        ArrayList<String> words = new ArrayList<>();
        
        JFrame frame = new JFrame("Memory game");
        JPanel cards = new JPanel();
        JPanel answer = new JPanel();

        frame.setLayout(new GridLayout(2, 1));
        cards.setLayout(new GridLayout(6, 6));
        answer.setLayout(new GridLayout(1, 2));
        arrs = makeArray();
        shuffle2DArray(arrs);
        
        frame.setSize(1024, 576);
        frame.add(cards);
        frame.add(answer);
        
        //make buttons 
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                JButton but = new JButton("?");
                but.addActionListener(new ButtonClickListener(i, j));
                but.setOpaque(true);
                but.setContentAreaFilled(true);
                buts.add(but);
                but.setBorderPainted(false);
                cards.add(but);
            }
        }

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
     
    private class ButtonClickListener implements ActionListener {
        public int x;
        public int y;
        
        public ButtonClickListener(int s, int t) {
            this.x = s;
            this.y = t;
        }

        public void disableButtons() {
            for (JButton b : buts) {
                b.setEnabled(false);
            }
        }

        public void enableButtons() {
            for (JButton b : buts) {
                b.setEnabled(true);
            }
        }
        

        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();
            
            if (flipped == 0 && gl > 0) {
                button.setText(arrs[x][y]);
                button.setBackground(Color.YELLOW);
                prev = button.getText();
                prevBut = button;
                flipped += 1;
            } else if (flipped == 1 && gl > 0) {
                button.setText(arrs[x][y]);
                if (!button.getText().equals(prev)) {
                    prevBut.setBackground(Color.RED);
                    button.setBackground(Color.RED);
                    disableButtons();
                    
                    Timer timer = new Timer(1000, new ActionListener() {
                        public void actionPerformed(ActionEvent evt) {
                            prevBut.setBackground(null);
                            button.setBackground(null);
                            button.setText("?");
                            prevBut.setText("?");
                            enableButtons();
                            flipped = 0;
                        }
                    });
                    timer.setRepeats(false);
                    timer.start();
                } else if (button.getText().equals(prev)) {
                    prevBut.setBackground(Color.GREEN);
                    button.setBackground(Color.GREEN);
                    prevBut.setEnabled(false);
                    button.setEnabled(false);
                    flipped = 0;
                    
                }
            }
        }
    }

    public String[][] makeArray() {
        ArrayList<String> words = new ArrayList<>();
        words.add("Chocolate");
        words.add("Candy");
        words.add("Lollipop");
        words.add("Gummy Bear");
        words.add("Toffee");
        words.add("Marshmallow");
        words.add("Brownie");
        words.add("Cupcake");
        words.add("Donut");
        words.add("Macaron");
        words.add("Jelly Bean");
        words.add("Fudge");
        words.add("Caramel");
        words.add("Bonbon");
        words.add("Truffle");
        words.add("Cheesecake");
        words.add("Muffin");
        words.add("Pudding");
        words.add("Tart");
        words.add("Cookie");
        words.add("Ice Cream");
        words.add("Sorbet");
        words.add("Gelato");
        words.add("Popsicle");
        words.add("Licorice");
        words.add("Nougat");
        words.add("Marzipan");
        words.add("Eclair");
        words.add("Churro");
        words.add("Gingerbread");
        words.add("Baklava");
        words.add("Panna Cotta");
        words.add("Creme Brulee");
        words.add("Tiramisu");
        words.add("Pecan Pie");
        words.add("Pavlova");
        words.add("Cannoli");
        words.add("Fruitcake");
        words.add("Danish");
        words.add("Pretzel");
        words.add("Scone");
        words.add("Shortbread");
        words.add("Meringue");
        words.add("Ladyfinger");
        words.add("Rock Candy");
        words.add("Peanut Brittle");
        words.add("Rice Krispies Treat");
        words.add("Swiss Roll");
        words.add("Taffy");
        words.add("Snickerdoodle");

        Collections.shuffle(words);
        ArrayList<String> wordList = new ArrayList<>();
        for (int p = 0; p < 18; p++) {
            wordList.add(words.get(p));
            wordList.add(words.get(p));
        }

        String[][] arr = new String[6][6];
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                arr[i][j] = wordList.get(count);
                count++;
            }
        }
        return arr;
    }

    public static void shuffle2DArray(String[][] array) {
        int rows = array.length;
        int cols = array[0].length;

        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                list.add(array[i][j]);
            }
        }

        Collections.shuffle(list);

        int index = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                array[i][j] = list.get(index++);
            }
        }
    }

    public static void main(String[] args) {
        new Memory();
    }
}
